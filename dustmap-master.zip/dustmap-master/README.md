# dustmap

Get reddening for lines of sight via <a href="http://adsabs.harvard.edu/abs/1998ApJ...500..525S">1998ApJ...500..525S</a>.
